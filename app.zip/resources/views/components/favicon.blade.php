<!-- App favicon -->
<link rel="shortcut icon" href="{{ Voyager::image(setting('site.favcion')) }}">
