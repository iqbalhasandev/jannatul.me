<!-- SCRIPTS -->
<script src="{{front_asset('js/jquery-1.12.3.min.js')}}"></script>
<script src="{{front_asset('js/jquery.easing.min.js')}}"></script>
<script src="{{front_asset('js/popper.min.js')}}"></script>
<script src="{{front_asset('js/bootstrap.min.js')}}"></script>
<script src="{{front_asset('js/jquery.waypoints.min.js')}}"></script>
<script src="{{front_asset('js/jquery.counterup.min.js')}}"></script>
<script src="{{front_asset('js/jquery.mCustomScrollbar.concat.min.js')}}"></script>
@stack('lib-scripts')
<script src="{{front_asset('js/isotope.pkgd.min.js')}}"></script>
<script src="{{front_asset('js/infinite-scroll.min.js')}}"></script>
<script src="{{front_asset('js/imagesloaded.pkgd.min.js')}}"></script>
<script src="{{front_asset('js/slick.min.js')}}"></script>
<script src="{{front_asset('js/contact.js')}}"></script>
<script src="{{front_asset('js/validator.js')}}"></script>
<script src="{{front_asset('js/custom.js')}}"></script>
<script src="{{front_asset('js/activenav.min.js')}}"></script>


@stack('extra-scripts')
